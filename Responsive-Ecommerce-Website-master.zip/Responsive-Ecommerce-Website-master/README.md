# Responsive-Ecommerce-Website
Front-end for an e-commerce clothes selling website.
## About
1- It is a responsive webpage containing nice animations. <br />
2- Contains a well authenticated contact, login and sinup froms.<br />
3- Contains many categories regarding clothes.<br />
4- A nice Footer.<br />
5- Authenticated Payment Page.<br />
5- A nice Cart Page.
## Screenshots
<img src="Demo_look/Web_look_1.PNG" width = "100%">
<img src="Demo_look/Web_look_2.PNG" width = "100%">
<img src="Demo_look/Web_look_3.PNG" width = "100%">
<img src="Demo_look/Web_look_4.PNG" width = "100%">
<img src="Demo_look/Web_look_5.PNG" width = "100%">
<img src="Demo_look/Web_look_6.PNG" width = "100%">
<img src="Demo_look/Web_look_7.PNG" width = "100%">
<img src="Demo_look/Web_look_8.PNG" width = "100%">
<img src="Demo_look/Web_look_9.PNG" width = "100%">
<img src="Demo_look/Web_look_10.PNG" width = "100%">

Hope this may help in your project someway...!
